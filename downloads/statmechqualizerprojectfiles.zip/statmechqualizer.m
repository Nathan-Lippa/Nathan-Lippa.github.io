% constants
physicalConstants.planckConstant_Js       = 6.62607015e-34; % h, not hbar
physicalConstants.boltzmannConstant_JperK = 1.380649e-23;
physicalConstants.speedOfLight_mps        = 299792458;
physicalConstants.atomicMassUnit_kg       = 1.66053906660e-27;

%general config
cfg.sampleRate_Hz         = 44100;   % audio sample rate (Nyquist = 1/2 sampleRate_Hz)
cfg.numberOfTaps          = 1025;    % FIR length, must be odd 
cfg.windowType            = 'hann';  % 'hamming', 'hann', or 'blackman'
cfg.designGridPoints      = 4097;    % frequency-sampling grid (0 to Nyquist, inclusive)
cfg.relativeAnchorFreq_Hz = 8800;    % where the distribution mean is placed in 'relative' mapping
cfg.clipMultOfBandRms     = 10;      % |H| is clipped at this multiple of its band RMS
cfg.lostProbWarning       = 0.05;    % warn if more than this fraction lies above Nyquist

% environmental config
cfg.mode = 'classical';             % 'classical' or 'quantum'

% Classical regime
cfg.classical.dim              = 3;              % 1, 2 or 3
cfg.classical.boxSideLengths_m = [0.3 0.3 0.3];  % side lengths [m]; first 'dimension' entries used
cfg.classical.temp_K           = 300;            % gas temperature [K]
cfg.classical.boundCond        = 'hard';         % 'hard' (round trip 2L) or 'periodic' (L)
cfg.classical.freqMapping      = 'relative';     % 'relative' or 'absolute'
cfg.classical.absScaleFactor   = 1;              % audio Hz per transit Hz (absolute mapping only)
% Species list: {name, number of particles}. Available names:
%   H2 He CH4 H2O Ne N2 O2 Ar CO2 Kr Xe SF6 etc
% or a custom mass in atomic mass units written as 'custom:72.6'.
cfg.classical.species = {
    'He', 2e24; ...
    'N2', 1e24; ...
    'O2', 3e23; ...
    'Ar', 6e21; ...
    'CO2', 3e20; ...
    'custom:5000', 5e22; ...
    };

% Quantum regime
cfg.quantum.dim              = 1;                 % 1, 2 or 3
cfg.quantum.boxSideLengths_m = [10 10 10]*1e-9;   % side lengths [m]
cfg.quantum.temp_K           = 1000;               % temperature [K]
cfg.quantum.boundCond        = 'hard';            % 'hard' or 'periodic'
cfg.quantum.freqMapping      = 'absolute';        % 'relative' or 'absolute'
cfg.quantum.absScaleFactor   = 1e-10;             % audio Hz per (E/h) in Hz (absolute mapping only)
% Species: electron, proton, neutron, He-3, Li-6, K-40 (fermions)
%          He-4, Li-7, Na-23, K-39, Rb-87 (bosons)
cfg.quantum.speciesName            = 'K-39';
cfg.quantum.numberOfParticles      = 2500;   % total number of particles
cfg.quantum.cutoffThermalEnergies  = 100;    % energies are kept up to this many kT above the top of the occupied range

nyquistFreq_Hz   = cfg.sampleRate_Hz/2;
audioFreqGrid_Hz = linspace(0, nyquistFreq_Hz, cfg.designGridPoints).'; % grid of frequencies

% check config is good to go
validateCommonConfig(cfg);         % stops on bad input
activeModeConfig = cfg.(cfg.mode); % the sub-struct for the selected mode
validateModeConfig(cfg.mode, activeModeConfig);

%% RUN FUNCTIONS
% function runn
switch cfg.mode
    case 'classical'
        densityResult = buildClassicalDensity(cfg, activeModeConfig, physicalConstants, audioFreqGrid_Hz);
    case 'quantum'
        densityResult = buildQuantumDensity(cfg, activeModeConfig, physicalConstants, audioFreqGrid_Hz);
end

% need to hard clip before filter design (mostly for bosonic distributions)
[targetMagResp, clippingInfo] = shapeMagResp( ...
    densityResult.probDensityPerHz, cfg.clipMultOfBandRms);

% filtering
[xIn, fs] = audioread("TestSound.wav");
if size(xIn, 2) > 1
    xIn = mean(xIn, 2);   % make mono if needed
end
[outputSignal, filterKernel, windowCoeffs] = designLinearPhaseFir(targetMagResp, xIn, cfg);

% plotting
figure(122)
plot(audioFreqGrid_Hz, targetMagResp)
title(sprintf("Target Freq Response (%s regime)", cfg.mode))
xlabel("Freq (Hz)")
ylabel("Magnitude (a.u.)")

analysisWindow = buildWindow(cfg.windowType, cfg.numberOfTaps);
noverlap = round(0.75*numel(analysisWindow));
nfft = 2048;

figure(123)
tiledlayout(2, 1, "TileSpacing", "compact", "Padding", "compact")

ax1 = nexttile;
spectrogram(xIn, analysisWindow, noverlap, nfft, fs, "yaxis");
title(ax1, "Input")
cl = clim(ax1);

ax2 = nexttile;
spectrogram(outputSignal, analysisWindow, noverlap, nfft, fs, "yaxis");
title(ax2, "Filtered Output")
clim(ax2, cl)


figure(124)

nfft = 2^nextpow2(numel(xIn));
Y = fft(outputSignal, nfft);

P2 = abs(Y / numel(outputSignal));
P1 = P2(1:nfft/2+1);
P1(2:end-1) = 2*P1(2:end-1);

f = fs*(0:nfft/2)/nfft;

plot(f, 20*log10(P1 + eps))
grid on
xlabel('Freq (Hz)')
ylabel('Magnitude (dB)')
title('Output Spectrum')

soundsc(outputSignal, fs)

%% Helper Functions
function validateCommonConfig(cfg)
    % Checks the settings shared by both modes and stops if there's an error
    if ~ischar(cfg.mode) || ~ismember(cfg.mode, {'classical', 'quantum'})
        error('cfg.mode must be ''classical'' or ''quantum''.');
    end
    if cfg.sampleRate_Hz <= 0
        error('cfg.sampleRate_Hz must be positive.');
    end
    if mod(cfg.numberOfTaps, 2) ~= 1 || cfg.numberOfTaps < 3
        error('cfg.numberOfTaps must be an odd integer >= 3.');
    end
    if 2*(cfg.designGridPoints - 1) < cfg.numberOfTaps
        error('cfg.designGridPoints is too small for cfg.numberOfTaps (need 2*(points-1) >= taps).');
    end
    if ~ismember(cfg.windowType, {'hamming', 'hann', 'blackman'})
        error('cfg.windowType must be hamming, hann, or blackman.');
    end
    if cfg.relativeAnchorFreq_Hz <= 0 || cfg.relativeAnchorFreq_Hz >= cfg.sampleRate_Hz/2
        error('cfg.relativeAnchorFreq_Hz must lie between 0 and Nyquist.');
    end
    if cfg.clipMultOfBandRms <= 1
        error('cfg.clipMultOfBandRms must be greater than 1.');
    end
end

function validateModeConfig(modeName, modeConfig)
    % Checks the settings of the selected mode.
    if ~ismember(modeConfig.dim, [1 2 3])
        error('dimension must be 1, 2 or 3.');
    end
    if numel(modeConfig.boxSideLengths_m) < modeConfig.dim || ...
            any(modeConfig.boxSideLengths_m(1:modeConfig.dim) <= 0)
        error('boxSideLengths_m needs at least "dimension" positive entries.');
    end
    if modeConfig.temp_K <= 0
        error('temp_K must be positive.');
    end
    if ~ismember(modeConfig.boundCond, {'hard', 'periodic'})
        error('boundCond must be ''hard'' or ''periodic''.');
    end
    if ~ismember(modeConfig.freqMapping, {'relative', 'absolute'})
        error('freqMapping must be ''relative'' or ''absolute''.');
    end
    if modeConfig.absScaleFactor <= 0
        error('absScaleFactor must be positive.');
    end
    switch modeName
        case 'classical'
            speciesTable = modeConfig.species;
            if ~iscell(speciesTable) || isempty(speciesTable) || size(speciesTable, 2) ~= 2
                error('cfg.classical.species must be a cell array with rows {name, count}.');
            end
            for rowIndex = 1:size(speciesTable, 1)
                particleCount = speciesTable{rowIndex, 2};
                if particleCount < 1 || particleCount ~= round(particleCount)
                    error('Particle counts must be positive integers.');
                end
            end
        case 'quantum'
            if ~ischar(modeConfig.speciesName)
                error('cfg.quantum.speciesName must be a character vector.');
            end
    end
end

function densityResult = buildClassicalDensity(cfg, classicalConfig, constants, audioFreqGrid_Hz)
    boltzmann = constants.boltzmannConstant_JperK; % Joules per Kelvin
    dim = classicalConfig.dim;
    boxSideLengths_m = classicalConfig.boxSideLengths_m(1:dim); % take dims in order provided
    boxMeasure = prod(boxSideLengths_m); % length, area or volume
    effBoxLength_m = boxMeasure^(1/dim); % geometric mean of the sides
    transitLengthFactor = getTransitLengthFactor(classicalConfig.boundCond); % based on hard vs. periodic
    transitLength_m = transitLengthFactor*effBoxLength_m;   % speed -> frequency: nu = v / transitLength
    temp_K = classicalConfig.temp_K;

    speciesTable = classicalConfig.species;
    numberOfSpecies = size(speciesTable, 1);
    speciesLabels = cell(numberOfSpecies, 1);
    speciesMasses_kg = zeros(numberOfSpecies, 1); % define to update
    speciesCounts = zeros(numberOfSpecies, 1); % define to update
    for spIdx = 1:numberOfSpecies
        [speciesLabels{spIdx}, speciesMasses_kg(spIdx)] = ...
            lookupClassicalSpecies(speciesTable{spIdx, 1}, constants);
        speciesCounts(spIdx) = speciesTable{spIdx, 2};
    end
    numberFractions = speciesCounts/sum(speciesCounts); % mixture weights

    thermalSpeedScale_mps = sqrt(boltzmann*temp_K./speciesMasses_kg); % sqrt(kbt/m)
    meanSpeedFactor = sqrt(2)*gamma((dim + 1)/2)/gamma(dim/2); % arises from the <v> integral :)
    meanSpeedPerSpecies_mps = thermalSpeedScale_mps*meanSpeedFactor; % apply factor to thermal speeds
    meanTransitFreqPerSpecies_Hz = meanSpeedPerSpecies_mps/transitLength_m; % convert to freq
    mixtureMeanTransitFreq_Hz = sum(numberFractions.*meanTransitFreqPerSpecies_Hz); % find true mean

    if strcmp(classicalConfig.freqMapping, 'relative')
        % force configured frequency anchor
        audioHzPerTransitHz = cfg.relativeAnchorFreq_Hz/mixtureMeanTransitFreq_Hz;
    else
        % use physical frequency as the audio frequency
        audioHzPerTransitHz = classicalConfig.absScaleFactor;
    end

    % Prob. density on the audio grid
    % Audio frequency f -> speed v = transitLength * f / audioHzPerTransitHz,
    % and the Jacobian dv/df converts a density per (m/s) into a density per Hz.
    speedAtGridPoint_mps = transitLength_m*audioFreqGrid_Hz/audioHzPerTransitHz;
    speedToAudioJacobian = transitLength_m/audioHzPerTransitHz;
    numberOfGridPoints = numel(audioFreqGrid_Hz);
    perSpeciesDensityPerHz = zeros(numberOfGridPoints, numberOfSpecies); % already number-weighted
    
    for speciesIndex = 1:numberOfSpecies
        thermalScale = thermalSpeedScale_mps(speciesIndex);
        normalization = thermalScale^dim*2^(dim/2 - 1)*gamma(dim/2);
        speedDensity = speedAtGridPoint_mps.^(dim - 1) .* ...
            exp(-speedAtGridPoint_mps.^2/(2*thermalScale^2))/normalization;
        perSpeciesDensityPerHz(:, speciesIndex) = numberFractions(speciesIndex)*speedDensity*speedToAudioJacobian;
    end
    probDensityPerHz = sum(perSpeciesDensityPerHz, 2);

    % check for nyquist!!
    nyquistSpeed_mps = transitLength_m*(cfg.sampleRate_Hz/2)/audioHzPerTransitHz;
    lostPerSpecies = 1 - gammainc(nyquistSpeed_mps^2./(2*thermalSpeedScale_mps.^2), dim/2);
    lostProbAboveNyquist = sum(numberFractions.*lostPerSpecies);
    if lostProbAboveNyquist > cfg.lostProbWarning
        warning('%.1f %% of the prob lies above Nyquist and is discarded. Consider a lower scale factor or relative mapping.', ...
            100*lostProbAboveNyquist);
    end
    
    % check for boundary conditions !! are these params actually classical
    % or not
    thermalDeBroglieWavelength_m = constants.planckConstant_Js./sqrt(2*pi*speciesMasses_kg*boltzmann*temp_K);
    degeneracyParameter = (speciesCounts/boxMeasure).*thermalDeBroglieWavelength_m.^dim;
    if any(degeneracyParameter > 0.1)
        warning('Degeneracy parameter n*lambda^d reaches %.2g: this gas is not classical. Consider quantum mode.', ...
            max(degeneracyParameter));
    end
    if any(boltzmann*temp_K > 0.01*speciesMasses_kg*constants.speedOfLight_mps^2)
        warning('kT exceeds 1%% of a rest energy: the non-relativistic Maxwell distribution is inaccurate.');
    end

    densityResult.probDensityPerHz    = probDensityPerHz;
    densityResult.lostProbAboveNyquist       = lostProbAboveNyquist;
end

function transitLengthFactor = getTransitLengthFactor(boundCond)
    % Hard walls: a particle must go there and back (2L) to repeat its motion,
    % and the allowed momentum components are h*n/(2L). Periodic: L and h*n/L.
    if strcmp(boundCond, 'hard')
        transitLengthFactor = 2;
    else
        transitLengthFactor = 1;
    end
end

function quantumResult = buildQuantumDensity(cfg, quantumConfig, constants, audioFreqGrid_Hz)
    % Quantum gas of one species (fermion or massive boson) in a d-dimensional box.
    %
    % The target is the energy distribution of the particles
    %     P(e) = g * rho(e) * f(e) / N
    % with e the kinetic energy measured from the lowest box level (ground level = 0), and
    %     f(e)   = 1/(exp((e - mu)/kT) + 1)   fermions (Fermi-Dirac)
    %     f(e)   = 1/(exp((e - mu)/kT) - 1)   bosons   (Bose-Einstein, mu < 0)
    %     rho(e) = V * S_d * p^(d-1) / (h^d * v)   continuum density of states per spin state,
    % where S_d = 2*pi^(d/2)/gamma(d/2) is the area of the unit sphere in d dimensions (the
    % Gamma function carries the hyperdimensional geometry), p(e) is the relativistic momentum
    % and v = de/dp the group velocity. Written as an integral over momentum this is
    %     N = g * V * S_d / h^d * integral( p^(d-1) f dp ).
    %
    % The quantization of the box enters through the chemical potential mu, which solves
    %     g * int f(e) de = N   (mu measured from the ground level) by means
    %     of an integral over the continuum density of states.
    %
    % Frequency mapping: 'relative' attaches the mean particle energy to the anchor freq, 
    % 'absolute' maps audio = scale * e/h. Probability per audio-grid cell is computed for 
    % each momentum.
    planck = constants.planckConstant_Js;
    boltzmann = constants.boltzmannConstant_JperK;
    dimension = quantumConfig.dim;
    boxSideLengths_m = quantumConfig.boxSideLengths_m(1:dimension);
    boxMeasure = prod(boxSideLengths_m); % length, area or volume
    thermalEnergy_J = boltzmann*quantumConfig.temp_K; % k_b T
    nyquistFreq_Hz = cfg.sampleRate_Hz/2;
    particleNumber = quantumConfig.numberOfParticles;
    speedOfLight = constants.speedOfLight_mps;

    speciesInfo = lookupQuantumSpecies(quantumConfig.speciesName, constants);
    spinDegeneracy = speciesInfo.spinDegeneracy;
    statisticsType = speciesInfo.statisticsType; % 'fermion' or 'boson'
    particleMass_kg = speciesInfo.mass_kg;

    % density of states: dN = g * V * S_d * p^(d-1) dp / h^d, 
    % so that n = densityPrefactor*integral(p^(d-1) f dp)
    shellArea = 2*pi^(dimension/2)/gamma(dimension/2); % S_d
    densityPrefactor = spinDegeneracy*shellArea/planck^dimension; % g * V * S_d / h^d

    % settings shared by the helper functions
    gas.dimension = dimension;
    gas.mass_kg = particleMass_kg;
    gas.statistics = statisticsType; % 'fermion' or 'boson'
    gas.thermalEnergy_J = thermalEnergy_J;
    gas.cutoffKT = quantumConfig.cutoffThermalEnergies;
    gas.constants = constants;

    % chemical potential (mu) and mean energy, both measured from the
    % ground level (e = 0)
    [mu_J, condensateFraction] = solveContinuumChemicalPotential(gas, densityPrefactor, ...
        particleNumber/boxMeasure, spinDegeneracy, constants);
    [~, thermalMeanEnergy_J] = integrateOccupation(mu_J, gas, 0);
    meanEnergy_J = thermalMeanEnergy_J*(1 - condensateFraction); % condensed particles sit at e = 0
    
    % frequency mapping: audio Hz per Joule
    if strcmp(quantumConfig.freqMapping, 'relative')
        if meanEnergy_J <= 0
            error(['Mean energy is zero (all particles in ground level), so relative mapping is undefined. ' ...
                'Use absolute mapping or a higher temperature.']);
        end
        audioHzPerJoule = cfg.relativeAnchorFreq_Hz/meanEnergy_J;
    else
        audioHzPerJoule = quantumConfig.absScaleFactor/planck; % audio = scale * (e/h)
    end

    % density per Hz evaluated at each audio-grid frequency
    % P(nu) = (g*S_d/(h^d*n)) * p^(d-1) * f(e) * dp/de * de/dnu, with
    %   e = nu/audioHzPerJoule, dp/de = 1/v (relativistic group velocity), de/dnu = 1/audioHzPerJoule
    nyquistMomentum = momentumFromKineticEnergy(nyquistFreq_Hz/audioHzPerJoule, particleMass_kg, constants);
    probPerIntegralUnit = densityPrefactor*boxMeasure/particleNumber; % converts p^(d-1)*f to probability per unit momentum

    gridKineticEnergy_J = audioFreqGrid_Hz(:)/audioHzPerJoule;
    gridMomentum = momentumFromKineticEnergy(gridKineticEnergy_J, particleMass_kg, constants);
    gridVelocity = gridMomentum*speedOfLight^2 ./ sqrt((gridMomentum*speedOfLight).^2 + (particleMass_kg*speedOfLight^2)^2);
    gridOccupation = continuumOccupation(gridKineticEnergy_J, mu_J, thermalEnergy_J, statisticsType);
    probDensityPerHz = probPerIntegralUnit*gridMomentum.^(dimension - 1).*gridOccupation./(gridVelocity*audioHzPerJoule);
    probDensityPerHz(~isfinite(probDensityPerHz)) = probDensityPerHz(2); % convert the 0Hz to equal to next bin Hz

    % totals for diagnositcs (integral of p^(d-1)*f over all momenta, and up to Nyquist)
    [~, ~, momentumNodes, integrand] = integrateOccupation(mu_J, gas, nyquistMomentum);
    cumulativeIntegral = trapz(momentumNodes, integrand); % total over all momenta
    insideBand = momentumNodes <= nyquistMomentum;
    cumulativeAtNyquist = trapz(momentumNodes(insideBand), integrand(insideBand)); % total up to Nyquist
    lostProbAboveNyquist = (cumulativeIntegral(end) - cumulativeAtNyquist)*probPerIntegralUnit;
    if lostProbAboveNyquist > cfg.lostProbWarning
        warning('%.1f %% of the prob lies above Nyquist and is discarded. Consider a smaller absolute scale factor.', ...
            100*lostProbAboveNyquist);
    end

    quantumResult.probDensityPerHz = probDensityPerHz;
end

function [mu_J, condensateFraction] = solveContinuumChemicalPotential(gas, densityPrefactor, ...
        numberDensity, spinDegeneracy, constants)
    % Solves n = densityPrefactor * integral(p^(d-1) f dp) for mu (measured from e = 0).
    % 3D bosons below the condensation temperature cannot hold all particles in the excited
    % states: mu = 0 and the remainder (condensateFraction) sits in the ground state at e = 0.
    thermalEnergy_J = gas.thermalEnergy_J;
    condensateFraction = 0;
    switch gas.statistics
        case 'fermion'
            fermiEnergy_J = estimateFermiKineticEnergy(gas.dimension, numberDensity, ...
                spinDegeneracy, gas.mass_kg, constants); % Fermi energy estimate
            lowerBound = -1000; % mu/kT; the Fermi energy bounds mu from above
            upperBound = fermiEnergy_J/thermalEnergy_J + gas.cutoffKT;
            for iter = 1:100
                reducedMu = 0.5*(lowerBound + upperBound); % iteratively redefine search bounds
                zeroMoment = integrateOccupation(reducedMu*thermalEnergy_J, gas, 0);
                if densityPrefactor*zeroMoment > numberDensity % iteratively check for n = densityPrefactor * integral
                    upperBound = reducedMu; % too many particles -> lower mu
                else
                    lowerBound = reducedMu;
                end
            end
            mu_J = reducedMu*thermalEnergy_J;
        case 'boson'
            maxThermalDensity = Inf; % 1D and 2D never condense in the continuum
            if gas.dimension == 3
                % most particles the excited states can hold (mu -> 0)
                maxThermalDensity = densityPrefactor*integrateOccupation(0, gas, 0);
            end
            if numberDensity > maxThermalDensity
                mu_J = 0;
                condensateFraction = 1 - maxThermalDensity/numberDensity;
                warning(['%.1f %% of the particles are in the ground-state condensate (e = 0, DC). ' ...
                    'Only the smooth part of the distribution is used for the filter.'], 100*condensateFraction);
            else
                lowerBound = -300; % s, where mu = -kT*exp(s) keeps mu < 0 automatically
                upperBound = 50;
                for iter = 1:100
                    logGap = 0.5*(lowerBound + upperBound);
                    zeroMoment = integrateOccupation(-thermalEnergy_J*exp(logGap), gas, 0);
                    if densityPrefactor*zeroMoment > numberDensity
                        lowerBound = logGap; % too many particles -> larger gap below zero
                    else
                        upperBound = logGap;
                    end
                end
                mu_J = -thermalEnergy_J*exp(logGap);
            end
    end
end

function [zeroMoment, meanEnergy_J, nodes, integrand] = integrateOccupation(mu_J, gas, bandMaxMomentum)
    % Integrates p^(d-1) * f(E(p)) over momentum
    % Returns the zeroth moment, the mean kinetic energy, and the nodes/integrand.
    thermalEnergy_J = gas.thermalEnergy_J;
    windowHalfWidth_J = gas.cutoffKT*thermalEnergy_J;
    maxEnergy_J = max(mu_J, 0) + windowHalfWidth_J;
    maxMomentum = momentumFromKineticEnergy(maxEnergy_J, gas.mass_kg, gas.constants);

    nodes = [logspace(log10(1e-18*maxMomentum), log10(maxMomentum), 4001).'; ...
             linspace(0, maxMomentum, 20001).']; % design finely spaced grid for numerical integration
    if strcmp(gas.statistics, 'fermion') && mu_J + windowHalfWidth_J > 0
        windowEnergies_J = linspace(max(mu_J - windowHalfWidth_J, 0), mu_J + windowHalfWidth_J, 20001).';
        nodes = [nodes; momentumFromKineticEnergy(windowEnergies_J, gas.mass_kg, gas.constants)];
    end
    if bandMaxMomentum > 0
        nodes = [nodes; linspace(0, min(bandMaxMomentum, maxMomentum), 8193).'];
    end
    nodes = unique(nodes(nodes > 0 & nodes <= maxMomentum)); % sorted, no p = 0

    kineticEnergy_J = kineticEnergyFromMomentumSquared(nodes.^2, gas.mass_kg, gas.constants);
    occupation = continuumOccupation(kineticEnergy_J, mu_J, thermalEnergy_J, gas.statistics);
    integrand = nodes.^(gas.dimension - 1).*occupation;
    zeroMoment = trapz(nodes, integrand);
    meanEnergy_J = trapz(nodes, kineticEnergy_J.*integrand)/zeroMoment;
end

function occupation = continuumOccupation(kineticEnergy_J, mu_J, thermalEnergy_J, statisticsType)
    % Mean occupation per spin state: Fermi-Dirac, or Bose-Einstein.
    switch statisticsType
        case 'fermion'
            occupation = 1./(exp((kineticEnergy_J - mu_J)/thermalEnergy_J) + 1);
        otherwise
            occupation = 1./expm1((kineticEnergy_J - mu_J)/thermalEnergy_J); % expm1 is exp(x) - 1 w/ safeguards for small x
    end
end

function momentum = momentumFromKineticEnergy(kineticEnergy_J, particleMass_kg, constants)
    % Inverse of the relativistic dispersion: p = sqrt(E(E + 2mc^2))/c.
    speedOfLight = constants.speedOfLight_mps;
    restEnergy_J = particleMass_kg*speedOfLight^2;
    momentum = sqrt(kineticEnergy_J.*(kineticEnergy_J + 2*restEnergy_J))/speedOfLight;
end

function kineticEnergy_J = kineticEnergyFromMomentumSquared(momentumSquared, particleMass_kg, constants)
    % Relativistic kinetic energy (rest energy excluded) from momentum squared.
    % Massive: E_k = sqrt(p^2c^2 + m^2c^4) - mc^2, evaluated as
    %          p^2c^2 / ( sqrt(p^2c^2 + m^2c^4) + mc^2 ) to avoid any weird behaviour.
    speedOfLight = constants.speedOfLight_mps;
    restEnergy_J = particleMass_kg*speedOfLight^2;
    momentumEnergySquared = momentumSquared*speedOfLight^2;
    kineticEnergy_J = momentumEnergySquared./(sqrt(momentumEnergySquared + restEnergy_J^2) + restEnergy_J);
end

function fermiEnergy_J = estimateFermiKineticEnergy(dimension, numberDensity, spinDegeneracy, particleMass_kg, constants)
    % Fermi momentum from the number density -> kinetic energy. 
    % Used to determine the energy cutoff.
    % Calculated by considering T = 0
    % 1D: n = g*2*pF/h
    % 2D: n = g*pi*pF^2/h^2 
    % 3D: n = g*(4/3)*pi*pF^3/h^3
    planck = constants.planckConstant_Js;
    switch dimension
        case 1
            fermiMomentum = planck*numberDensity/(2*spinDegeneracy);
        case 2
            fermiMomentum = planck*sqrt(numberDensity/(pi*spinDegeneracy));
        case 3
            fermiMomentum = planck*(3*numberDensity/(4*pi*spinDegeneracy))^(1/3);
    end
    fermiEnergy_J = kineticEnergyFromMomentumSquared(fermiMomentum^2, particleMass_kg, constants);
end

% Lookup tables
function [speciesLabel, speciesMass_kg] = lookupClassicalSpecies(speciesName, constants)
    % Returns label and mass [kg] of a classical gas species.
    % Masses are atomic mass units.
    % 'custom:<mass in u>' defines an arbitrary particle.
    if strncmpi(speciesName, 'custom:', 7)
        massInAtomicUnits = str2double(speciesName(8:end));
        if isnan(massInAtomicUnits) || massInAtomicUnits <= 0
            error('Could not read a positive mass from "%s" (use e.g. ''custom:72.6'').', speciesName);
        end
        speciesLabel   = sprintf('custom (%.4g u)', massInAtomicUnits);
        speciesMass_kg = massInAtomicUnits*constants.atomicMassUnit_kg;
        return;
    end
    classicalDatabase = { ...
        'H2',  2.01588;  
        'He',  4.002602; 
        'CH4', 16.0425;  
        'H2O', 18.01528;
        'Ne',  20.1797;   
        'N2',  28.0134;  
        'O2',  31.998;   
        'Ar',  39.948;
        'CO2', 44.0095;
        'Kr',  83.798;  
        'Xe',  131.293;   
        'SF6', 146.055 };
    rowIndex = find(strcmpi(classicalDatabase(:,1), speciesName), 1);
    if isempty(rowIndex)
        error('Unknown classical species "%s". Available: %s, or ''custom:<mass in u>''.', ...
            speciesName, strjoin(classicalDatabase(:,1).', ', '));
    end
    speciesLabel   = classicalDatabase{rowIndex, 1};
    speciesMass_kg = classicalDatabase{rowIndex, 2}*constants.atomicMassUnit_kg;
end

function speciesInfo = lookupQuantumSpecies(speciesName, constants)
    % Returns type, mass and spin degeneracy for a quantum species.
    % Statistics follow from the parity of the number of fermionic constituents
    % (protons + neutrons + electrons) of the neutral atom.
    % Atoms: spinDegeneracy = (2J+1)(2I+1) of the ground state
    %   J: orbital + spin angular momenta
    %   I: nuclear spin
    % levels treated as degenerate.
    u = constants.atomicMassUnit_kg;
    quantumDatabase = { ...
        'electron', 'fermion', 9.1093837015e-31,  2; ...
        'proton',   'fermion', 1.67262192369e-27, 2; ...
        'neutron',  'fermion', 1.67492749804e-27, 2; ...
        'He-3',     'fermion', 3.0160293201*u,    2; ...
        'Li-6',     'fermion', 6.0151228874*u,    6; ...
        'K-40',     'fermion', 39.963998166*u,   18; ...
        'He-4',     'boson',   4.00260325413*u,   1; ...
        'Li-7',     'boson',   7.0160034366*u,    8; ...
        'Na-23',    'boson',   22.989769282*u,    8; ...
        'K-39',     'boson',   38.9637064864*u,   8; ...
        'Rb-87',    'boson',   86.909180527*u,    8 };
    rowIndex = find(strcmpi(quantumDatabase(:,1), speciesName), 1);
    if isempty(rowIndex)
        error('Unknown quantum species "%s". Available: %s.', ...
            speciesName, strjoin(quantumDatabase(:,1).', ', '));
    end
    speciesInfo.name            = quantumDatabase{rowIndex, 1};
    speciesInfo.statisticsType  = quantumDatabase{rowIndex, 2};
    speciesInfo.mass_kg         = quantumDatabase{rowIndex, 3};
    speciesInfo.spinDegeneracy  = quantumDatabase{rowIndex, 4};
end


% Filter design stuff
function [targetMagResp, clippingInfo] = shapeMagResp(probDensityPerHz, clipMult)
    % Magnitude response from the prob density
    % peaks above clipMult * (band RMS of |H|) are hard-clipped &
    % done BEFORE normalization so spikes cannot overpower distribution
    rawMag = max(probDensityPerHz, 0);
    if sum(rawMag.^2) <= 0 % catch for errors
        error('No prob falls inside the band. Adjust the mapping (scale factor or mode).');
    end
    bandRmsMag = sqrt(mean(rawMag.^2)); % root mean squared of the distribution
    clipLevel = clipMult*bandRmsMag; % level to clip
    targetMagResp = min(rawMag, clipLevel); % determine target magnitude response

    clippedMask = rawMag > clipLevel; % mask it
    clippingInfo.anyClipped = any(clippedMask); % return what was clipped
    clippingInfo.fractionOfGridPointsClipped = mean(clippedMask); % how much got clipped
    clippingInfo.fractionOfPowerRemoved = 1 - sum(targetMagResp.^2)/sum(rawMag.^2); % how much power lost
    clippingInfo.clipLevel = clipLevel; % clip level
    clippingInfo.rawMag = rawMag; % original distribution
end

function [y, filterKernel, windowCoefficients] = designLinearPhaseFir(magnitudeOnGrid, inputSignal, cfg)
    % Freq-sampling + window design of a FIR filter
    %   1. Treat the sampled magnitude as a zero-phase spectrum and mirror it
    %      to negative frequencies
    %   2. Inverse FFT gives a real symmetric imp response centred at n = 0
    %   3. Take numberOfTaps samples around the centre, multiply by the window
    %   4. Scale to max of filtered signal.
    numberOfGridPoints = numel(magnitudeOnGrid);
    fftLength = 2*(numberOfGridPoints - 1);
    magnitudeOnGrid = magnitudeOnGrid(:);
    fullSymmetricSpectrum = [magnitudeOnGrid; flipud(magnitudeOnGrid(2:end-1))]; % append negative freqs
    zeroPhaseImpulseResponse = real(ifft(fullSymmetricSpectrum));
        
    halfLength = (cfg.numberOfTaps - 1)/2;
    tapOffsets = (-halfLength:halfLength).';
    circularIndices = mod(tapOffsets, fftLength) + 1; % negative offsets wrap around
    idealTruncatedKernel = zeroPhaseImpulseResponse(circularIndices);
        
    windowCoefficients = buildWindow(cfg.windowType, cfg.numberOfTaps);
    windowedKernel = idealTruncatedKernel.*windowCoefficients;
    
    % normalize output signal based on input signal peak magnitude
    nfft = 8192;
    H = fft(windowedKernel, nfft);
    X = fft(inputSignal, nfft);
    [~, k] = max(abs(X));

    filterKernel = windowedKernel / abs(H(k));
    
    y = filter(filterKernel, 1, inputSignal);
end

function windowCoefficients = buildWindow(windowType, numberOfTaps)
    % Symmetric window of odd length numberOfTaps
    sampleIndex = (0:numberOfTaps-1).';
    normalizedPosition = sampleIndex/(numberOfTaps - 1);
    switch windowType
        case 'hamming'
            windowCoefficients = 0.54 - 0.46*cos(2*pi*normalizedPosition);
        case 'hann'
            windowCoefficients = 0.5 - 0.5*cos(2*pi*normalizedPosition);
        case 'blackman'
            windowCoefficients = 0.42 - 0.5*cos(2*pi*normalizedPosition) + 0.08*cos(4*pi*normalizedPosition);
    end
end
